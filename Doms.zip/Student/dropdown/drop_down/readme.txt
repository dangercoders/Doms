Use dump_dd.txt file to create and populate the mysql database tables. 
At the beginning of the dd.php file in marked places enter the database details
For any problem in using the script use the discussion forum at www.plus2net.com to post your error, bugs etc. 

Use the contact us page at www.plus2net.com to reach us. 

This is downloaded from www.plus2net.com 
Please don't  remove the link to www.plus2net.com 
This is for your learning only not for commercial use. 
The author is not responsible for any type of loss or problem or damage on using this script.
You can use it at your own risk.

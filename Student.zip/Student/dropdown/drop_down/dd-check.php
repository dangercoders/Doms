<?php
//***************************************
// This is downloaded from www.plus2net.com //
/// You can distribute this code with the link to www.plus2net.com ///
//  Please don't  remove the link to www.plus2net.com ///
// This is for your learning only not for commercial use. ///////
//The author is not responsible for any type of loss or problem or damage on using this script.//
/// You can use it at your own risk. /////
//*****************************************

?>

<!doctype html public "-//w3c//dtd html 3.2//en">

<html>

<head>
<title>Demo Multiple drop down list box from plus2net</title>
</head>

<body>
<?Php
$cat=$_POST['cat'];
$subcat=$_POST['subcat'];

echo "Value of \$cat = $cat <br>Value of \$subcat = $subcat ";


?>
<br><br>
<a href=dd.php>Reset and start again</a>

<br><br>

<center><a href='http://www.plus2net.com' rel="nofollow">PHP SQL HTML free tutorials and scripts</a>

</center> 
</body>

</html>

<?
$username="shubham1_doms";
$password=";UP,pTlp-{n)";
$database="shubham1_doms";
$servername = "localhost";
$dsn= "mysql:host=$servername;dbname=$database";
?>
<?
$username="shubham1_doms";
$password="PSR3fbN0bs58";
$database="shubham1_doms";
$servername = "localhost";
$dsn= "mysql:host=$servername;dbname=$database";
?>